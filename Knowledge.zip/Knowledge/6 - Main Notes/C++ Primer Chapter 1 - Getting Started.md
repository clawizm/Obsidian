
2024-12-09 11:01

Status:

Tags:

Links: [[C++ Primer 5th Edition]]

# C++ Primer Chapter 1 - Getting Started

## **Writing a Simple C++ Program
- Every C++ Program contains one or more *functions*
	- **One must be named *main***
		- This *main* function is required to return type of *int*.
- ### **Elements Of A Function
	- A functions contains four elements
	- *Return type* - 
	- *Function name*
	- *Parameter List* - enclosed in parentheses, and can be empty
	- *Function Body* - Block of statements starting with an open curly brace and ending with a close curly brace.
## **Input/Output**
- The language itself does not define any statements to do input or output, and instead the standard library contains the iostream library.
- *istream* - The input stream type.
	- *cin* - An object of type istream used to handle input.
- *ostream* - The output stream type.
	- *cout* - An object of type ostream used to handle streaming standard outputs.
	- cerr - Referred to as the standard error, for warning and error messages. 
	- clog - Used to stream output for general information about the execution of the program.

## References