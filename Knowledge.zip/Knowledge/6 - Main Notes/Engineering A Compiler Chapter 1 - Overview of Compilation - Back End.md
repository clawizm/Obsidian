
2024-12-08 17:48

Status:

Tags:

Links: [[Engineering A Compiler Chapter 1 - Overview of Compilation]]

# Engineering A Compiler Chapter 1 - Overview of Compilation - Back End

## **Key Points
- Focuses on mapping the Definitive [[Engineering A Compiler Chapter 1 - Overview of Compilation#^4d4e6e |Intermediate Representation]] to the target machine instruction set and the finite resources of the target machine.
- **ASSUMES NO SYNCTACTIC OR SEMANTIC ERRORS DUE TO THE INPUT TO THE BACKEND BEING CREATED BY THE FRONT END.
## Instruction Selection
- The first stage in the Back End, where code generation begins. This stages involves rewriting the IR operations into target machine operations.
- Maps each IR operation, in its context, into one or more target machine operations.
- This instruction selector takes advantage of a target machine's special operations.
### *Example* 
![[Pasted image 20241208193733.png]]		
Here is an example of converting the above IR code into Machine-Specific Instructions.
![[Pasted image 20241208193815.png]]
## **Register Allocation
- Due to the compiler deliberately ignoring the fact that a target machine has a limited set of registers, the compiler uses virtual registers which must be mapped onto actual target-machine registers.
- This leads to the register allocator deciding at each point in the code which values should reside in the target-machine registers. Then it will rewrite the code to reflect its decisions.


## References

## **Key Terms
- *Virtual Register* - A symbolic register name that the compiler uses to indicate that a value can be stored in a register.