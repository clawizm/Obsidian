
2024-12-09 12:27

Status:

Tags:

Links: [[C++ Notes]]

# C++ Common Keywords

## *while*
- loops until the condition has been met, where in every iteration the statement block is executed.
- The condition(s) are stored in parenthesis that are placed directly after the while keyword.
- The statement is stored in curly brackets following the condition.
- Examples:
	 ![[Pasted image 20241209122850.png]]
	![[Pasted image 20241209122920.png]]
## *for*
- Same as in python, where the loop is defined at initialization. The start and stop values are given to the *for* keyword.
- Examples:
	![[Pasted image 20241209123251.png]]
## *if*
- Supports conditional execution.
- The statement that is executed by an if block is contained in curly brackets, while the condition is immediately succeeding the if keyword and is stored in parenthesis. 
## References