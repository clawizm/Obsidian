
2024-12-08 15:42

Status:

Tags:

Links: [[Engineering A Compiler 2nd Edition]] [[Engineering A Compiler Chapter 1 - Overview of Compilation - Front End]]

# Engineering A Compiler Chapter 2 - Scanners
- The task of a scanner is to transform a stream of characters into a stream of words in the input language.
- Each of these words must be classified into a syntactic category, or "part of speech".

## Example of Scanner Code Blocks (Using [[Engineering A Compiler Chapter 2 - Scanners#^4a48a7|Transition Diagrams]])

- Below is examples of Code written for the Scanner of a compiler, where we show how the scanner can look for a particular keyword, and then expand that structure to search for multiple keywords in the same iteration.
- **EACH OF THESE ARE CALLED 'RECOGNIZERs'**
- Each of these images are called [[Engineering A Compiler Chapter 2 - Scanners#^4a48a7|Transition Diagrams]]
- Step 1: *Search for the Keyword 'new'*	
	![[Pasted image 20241208201610.png]]
- Step 2: *Search for the Keyword 'while'*
	![[Pasted image 20241208201953.png]]	
- Step 3: *Create one Recognizer to search for the Keywords 'new' and 'not'.*
	![[Pasted image 20241208202128.png]]
- Step 4: *Combined all 3 of the previous recognizers to create one that searches for 'while', 'new', and 'not' in O(n).*
	![[Pasted image 20241208202407.png]]
## **Finite Automata**
- A formal mathematical object that can be used to represent a [[Engineering A Compiler Chapter 2 - Scanners#^4a48a7|Transition Diagram]]
- A formalism for recognizers that has a finite set of states, an alphabet, a transition function, a start state, and one or more accepting states.
- Formally, a finite automaton is a five-tuple (S, $\varSigma$, $\delta$, s$_0$, S$_A$)
	- S is the finite set of states in the recognizer, along with an error state s$_e$.
	- $\varSigma$ ([[Math Symbol Notes#^d86d1a|Sigma]]) is the finite alphabet used by the recognizer. Typically $\varSigma$ is the union of the edge labels in the transition diagram.
	- $\delta(s,c)$ is the recognizer's transition function. It maps each state *s* $\Huge \epsilon$ S and each character *c* $\Huge \epsilon$ $\varSigma$ into some next state. In state s$_i$ with input character *c* , the finite automata takes the transition s$_i$ $\xrightarrow{c} \large\delta(\large s_i, c)$.
	- s$_0$ $\Large\epsilon$ S is the designated start state.
	- S$_A$ is the set of accepting states, S$_A$ $\subseteq S$. Each state in S$_A$ appears as a double circle in the transition diagram.
### Finite Automata Examples
![[Pasted image 20241208210208.png]]
 ## **Key Terms
- *Recognizer* - A program that identifies specific words in a stream of characters.
- *Syntactic Category* - A classification of words according to their grammatical usage.
- *Microsyntax* - The lexical structure of a language.
- *Transition Diagrams* - Abstractions of the code that would be required to implement recognizers. ^4a48a7
## References
