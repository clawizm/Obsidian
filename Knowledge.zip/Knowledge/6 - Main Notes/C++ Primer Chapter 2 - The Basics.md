
2024-12-09 13:21

Status:

Tags:

Links:  [[C++ Primer 5th Edition]]

# C++ Primer Chapter 2 - The Basics

## Primitive Built-In Types
- These are data structures that are provided by the language.
- There are two main types provided: *arithmetic types* and *void*
- *Arithmetic Types* represent characters, integers, Boolean values, and floating-point numbers.
- *Void* type has no associated values and can be used only in a few circumstances, most commonly as the return type for functions that do not return a value.
### Arithmetic Types
- Can be divided further into two categories: *integral types* and *floating-point types*.
	![[Pasted image 20241209132621.png]]
- Example
	![[Pasted image 20241209133141.png]]
#### **Signed and Unsigned Types**
 - Except for bool and the extended character types, the integral types may be signed or unsigned.
	 - Signed Type - Represents negative or positive numbers (including zero)
	 - Unsigned Type  - Represents only values greater than or equal to zero.
- Example signed types include: *int, short, long, and long long*
	- These types can become unsigned, by inserting the word *unsigned* before the type. (Such as *unsigned int*)
- **ADVICE FOR USING SIGNED AND UNSIGNED TYPES**
	![[Pasted image 20241209133703.png]]
	
## References