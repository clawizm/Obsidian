
2024-12-09 08:48

Status:

Tags:

Links: 

# Math Symbol Notes

## **Greek Symbols**

### $\varSigma$ (Sigma)
- #### **Summation Notation** 
	- Can be used to denote summation, which is the addition of a sequence of numbers (called Summation Notation).
	- Example
	 ![[Pasted image 20241209090947.png]]
- #### **Eigenvalues (Linear Algebra)
	- Used to represent at diagonal matrix containing singular values in the Singular Value Decomposition (SVD) of a matrix.
- #### **Set Theory ^d86d1a
	- Used to denote specific sets or properties, such as $\varSigma$-Algebras in probability theory, which are structures used to define measures and integrate functions. 
## References