
2024-12-08 17:51

Status:

Tags:

Links: [[Engineering A Compiler Chapter 1 - Overview of Compilation]] 

# Engineering A Compiler Chapter 1 - Overview of Compilation - Optimizer

## Optimizer

^89d568

- Takes an IR program as its input and produces a semantically equivalent IR program as its output.
- Due to this input and outputting an IR program, this results in no changes being made to the Front End or Back End.
- This optimizer can be used to either write a faster target program from the Back End, or a smaller target program from the Back End.
- Analyzes the IF form of the code to discover facts about the context and uses that contextual knowledge to rewrite the code so that it computes the same answer in a more efficient way.
### **Examples of Optimization**
- Reduce application's running time.
- Reduce the size of the compiled code
- Reduce the energy consumed by the processor when evaluating the code.

### **IR Examples
- ![[Pasted image 20241208191737.png]]
## References

