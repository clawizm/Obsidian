
2024-12-08 15:39

Status:

Tags:

Links: [[Engineering A Compiler 2nd Edition]]

# Engineering A Compiler Chapter 1 - Overview of Compilation

## **Examples of Techniques used by Compilers
- [[Greedy Algorithms Notes | Greedy Algorithms]] (register allocation)
- [[Heuristic Search Techniques]] (List scheduling)
- [[Graph Algorithms]] (dead-code elimination)
- [[Dynamic Programming]] (instruction selection)
- [[Finite Automata and Push Down Automata]] (Scanning and Parsing)
- [[Fixed-Point Algorithms]] (Data-Flow Analysis)
## **Fundamental Principles of Compilation
- *The compiler must preserve the meaning of the program being compiled.*
	- Correctness is a fundamental issue in programming, where the compiler must preserve correctness by faithfully implementing the "meaning" of its input program.
	- **INCORRET TRANSLATION IS UNACCEPTABLE!
- *The compiler must improve the input program in some discernible way.*
	- Traditionally, a compiler improves a program by making it directly executable on some target machine. (Think TPAT, and the fact the py files wouldn't run on most PCs, but the executable works without python even installed)
## **Compiler Structure
- ![[Pasted image 20241208164526.png]]
- A compiler is composed of two major pieces, the [[Engineering A Compiler Chapter 1 - Overview of Compilation - Front End|Front End]] and the [[Engineering A Compiler Chapter 1 - Overview of Compilation - Back End|Back End]], with an optional third component in between the two, called the [[Engineering A Compiler Chapter 1 - Overview of Compilation - Optimizer#^89d568|Optimizer]].
- By splitting the work of the compiler into two pieces, we are able to create a single front end that works for multiple machines on the same language, where the only changes needed would be to the [[Engineering A Compiler Chapter 1 - Overview of Compilation - Back End|Back End]]
- This also allows for multiple programming languages to be able to use the same back end, and only needing to update the front end for each specific programming language.

## References

## **Key Terms
- ***Intermediate Representation*** - Data Structure or code format that serves as an abstraction of a source program, capturing its structure and semantics in a way that is independent of both the source language and the target machine. ^4d4e6e