
2024-12-08 13:43

Status:

Tags: 

Links: [[CS8803-008 Compilers - Theory & Practice]]

# **P1L1 - Introduction To Compilers**
## **Compilers Overview**
### ***Compiler Example***
- A program that translates a program from a source language into a target language.
- This Involves taking a Source file, feeding it to a compiler (Program), which in turn outputs an executable file (a file format that can be interpreted by the CPU), and then gives this executable to the Processor as to execute. (This means that the source file is turned into instructions that can be read by the CPU.) 
	![[Pasted image 20241208140222.png]]
	- Think of Assembly
### ***Interpreter Example***
- This involves taking a source file, feeding it to a Interpreter, which then interprets the source code line by line, and displaying the results of the source file line by line. (This does not generate an executable)
	- Think of Python
- These programs execute much slower than a compiled program.
### ***Why Compilers***
- It is much more difficult to maintain and update code written in low-level languages as opposed to high level languages. (Assembly is harder to use than C which is harder to use than Python)
- This mainly stems from abstractions that are made in high-level language, while these abstractions do not exist in low-level, and instead things are often explicitly defined (such as arrays and the memory blocks they occupy)
### ***How Compilers Work***
- ![[Pasted image 20241208143119.png]]
- The first step in the compiling process is to have a parser request a token from the scanner, which then gives the parser a token.
- The scanner reads the lines of source file, while the parser ensures that the line is a compiling able line. It is similar to your eyes reading a sentence, and your brain verifying it for syntax and correctness.
#### ***Parser***
- Verifies that the words returned by the scanner are legal words which are expected in that sentence (line of code).
- Tracking the amount of amount of sentence that is being seen, being processed, being translated, etc.
- Invokes the scanner
#### ***Scanner***
- Reads a source file line by line.
#### ***Semantic Action***
- Determines if a sentence (line of code) has the right meaning.
- This can raise a semantic error
	- Example: Trying to add a character to an integer. 


## References
- [P1L1: Introduction to Compilers Playlist](https://edstem.org/us/courses/48900/lessons/79180)
- 